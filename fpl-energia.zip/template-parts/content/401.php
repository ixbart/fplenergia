<img height="1" width="1" style="display:none" src="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->src ?>" data-img="in38ace4a7" srcset="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->alt ?>">
  <!--  End Meta Pixel Code  -->


  <div class="utility_component">
    <div class="utility_form-block w-password-page w-form">
      <form id="email-form" name="email-form" data-name="Email Form" action="<?php echo add_query_arg('action','postpass',wp_login_url()) ?>" method="post" class="utility_form w-password-page" data-wf-page-id="674ed779832f7ff504305b96" data-wf-element-id="60d3fa3a5a19c1169cd58c4100000000000c"><img width="106" src="<?php echo udesly_get_image(_u('i4abef31c', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i4abef31c', 'img'))->alt ?>" class="utility_image" data-img="i4abef31c" srcset="<?php echo udesly_get_image(_u('i4abef31c', 'img'))->srcset ?>">
        <h3>Protected Page</h3>
        <div class="padding-xxsmall"></div><input class="form_input w-password-page w-input" autofocus="true" maxlength="256" name="post_password" data-name="field" placeholder="Enter your password" type="password" id="pass">
        <div class="padding-xxsmall"></div><input type="submit" data-wait="Please wait..." class="button w-password-page w-button" value="Submit">
        <div class="form_message-error-wrapper w-password-page w-form-fail">
          <div class="form_message-error">
            <div>Incorrect password. Please try again.</div>
          </div>
        </div>
        
        
      </form>
    </div>
  </div>
  
  