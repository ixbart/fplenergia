<img height="1" width="1" style="display:none" src="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->src ?>" data-img="in38ace4a7" srcset="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('in38ace4a7', 'img'))->alt ?>">
  <!--  End Meta Pixel Code  -->


  <div class="global-styles w-embed">
    <style>
/* Ensure all elements inherit the color from their parent */
body * {
    color: inherit;
}
a,
.w-input,
.w-select,
.w-tab-link,
.w-nav-link,
.w-slider-arrow-left,
.w-slider-arrow-right,
.w-dropdown-btn,
.w-dropdown-toggle,
.w-dropdown-link {
    color: inherit;
    text-decoration: inherit;
    font-size: inherit;
}
/* Focus state style for keyboard navigation for the focusable elements */
*[tabindex]:focus-visible,
input[type="file"]:focus-visible {
    outline: 0.125rem solid #4d65ff;
    outline-offset: 0.125rem;
}
/* Get rid of top margin on the first element in any rich text element */
.w-richtext > :not(div):first-child,
.w-richtext > div:first-child > :first-child {
    margin-top: 0 !important;
}
/* Get rid of bottom margin on the last element in any rich text element */
.w-richtext > :last-child,
.w-richtext ol li:last-child,
.w-richtext ul li:last-child {
    margin-bottom: 0 !important;
}
/* Prevent all click and hover interaction with an element */
.pointer-events-off {
    pointer-events: none;
}
/* Enables all click and hover interaction with an element */
.pointer-events-on {
    pointer-events: auto;
}
/* Create a class of .div-square which maintains a 1:1 dimension of a div */
.div-square::after {
    content: "";
    display: block;
    padding-bottom: 100%;
}
/* Make sure containers never lose their center alignment */
.container-medium,
.container-small,
.container-large {
    margin-right: auto !important;
    margin-left: auto !important;
}
/* Apply "..." after 3 lines of text */
.text-style-3lines {
    display: -webkit-box;
    overflow: hidden;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
}
/* Apply "..." after 2 lines of text */
.text-style-2lines {
    display: -webkit-box;
    overflow: hidden;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
/* Adds inline flex display */
.display-inlineflex {
    display: inline-flex;
}
/* These classes are never overwritten */
.hide {
    display: none !important;
}
@media screen and (max-width: 991px) {
    .hide,
    .hide-tablet {
        display: none !important;
    }
}
@media screen and (max-width: 767px) {
    .hide-mobile-landscape {
        display: none !important;
    }
}
@media screen and (max-width: 479px) {
    .hide-mobile {
        display: none !important;
    }
}
.margin-0 {
    margin: 0rem !important;
}
.padding-0 {
    padding: 0rem !important;
}
.spacing-clean {
    padding: 0rem !important;
    margin: 0rem !important;
}
.margin-top {
    margin-right: 0rem !important;
    margin-bottom: 0rem !important;
    margin-left: 0rem !important;
}
.padding-top {
    padding-right: 0rem !important;
    padding-bottom: 0rem !important;
    padding-left: 0rem !important;
}
.margin-right {
    margin-top: 0rem !important;
    margin-bottom: 0rem !important;
    margin-left: 0rem !important;
}
.padding-right {
    padding-top: 0rem !important;
    padding-bottom: 0rem !important;
    padding-left: 0rem !important;
}
.margin-bottom {
    margin-top: 0rem !important;
    margin-right: 0rem !important;
    margin-left: 0rem !important;
}
.padding-bottom {
    padding-top: 0rem !important;
    padding-right: 0rem !important;
    padding-left: 0rem !important;
}
.margin-left {
    margin-top: 0rem !important;
    margin-right: 0rem !important;
    margin-bottom: 0rem !important;
}
.padding-left {
    padding-top: 0rem !important;
    padding-right: 0rem !important;
    padding-bottom: 0rem !important;
}
.margin-horizontal {
    margin-top: 0rem !important;
    margin-bottom: 0rem !important;
}
.padding-horizontal {
    padding-top: 0rem !important;
    padding-bottom: 0rem !important;
}
.margin-vertical {
    margin-right: 0rem !important;
    margin-left: 0rem !important;
}
.padding-vertical {
    padding-right: 0rem !important;
    padding-left: 0rem !important;
}
/* Apply "..." at 100% width */
.truncate-width {
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
/* Removes native scrollbar */
.no-scrollbar {
    -ms-overflow-style: none;
    overflow: -moz-scrollbars-none;
}
.no-scrollbar::-webkit-scrollbar {
    display: none;
}
/* Base style for all slider dots */
.w-slider-dot {
    width: 12px;
    height: 12px;
    background-color: #cccccc; /* Default inactive color */
    border-radius: 50%;
    display: inline-block;
    margin: 0 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}
/* Style for the active slider dot */
.w-slider-dot.w-active {
    background-color: #ffcb05; /* Active color */
}
</style>
  </div>
  <div class="page-wrapper">
    <div data-animation="over-right" class="navbar1_component w-nav" data-easing2="ease" fs-scrolldisable-element="smart-nav" data-easing="ease" data-collapse="medium" data-w-id="f389e4cb-bd30-5c95-623e-0a1dce1fc1ca" role="banner" data-duration="400">
      <div class="navbar1_container">
        <div class="menu-logo"><img loading="lazy" src="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->alt ?>" class="navbar1_logo" data-img="i7dfc681c" srcset="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->srcset ?>"></div>
        <nav role="navigation" class="navbar1_menu is-page-height-tablet w-nav-menu">
          <div class="navbar1_menu-links">
            <a href="<?php echo _u('a-78721987','link'); ?>" class="navbar1_link w-nav-link" data-text="t46975cf" data-link="a-78721987"><?php echo _u('t46975cf','text'); ?></a>
            <a href="<?php echo _u('a9a885ac','link'); ?>" class="navbar1_link w-nav-link" data-text="tn680b60ad" data-link="a9a885ac"><?php echo _u('tn680b60ad','text'); ?></a>
            <a href="<?php echo _u('aa7d410f','link'); ?>" class="navbar1_link w-nav-link" data-text="t260aaccc" data-link="aa7d410f"><?php echo _u('t260aaccc','text'); ?></a>
          </div>
          <div class="navbar1_menu-buttons">
            <a href="<?php echo _u('a13b2219d','link'); ?>" class="button is-mobile w-button" data-text="t43219700" data-link="a13b2219d"><?php echo _u('t43219700','text'); ?></a>
          </div>
        </nav>
        <div class="navbar1_menu-button w-nav-button">
          <div id="menu-trigger" class="menu-icon1">
            <div class="menu-icon1_line-top"></div>
            <div class="menu-icon1_line-middle">
              <div class="menu-icon1_line-middle-inner"></div>
            </div>
            <div class="menu-icon1_line-bottom"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="main-wrapper">
      <header class="section_header5 text-color-alternate">
        <div class="header_component1">
          <div class="padding-global">
            <div class="container-large">
              <div class="header5_content">
                <div class="padding-section-large">
                  <div class="max-width-large">
                    <h1 class="heading-style-h1" data-textarea="ta790c872c"><?php echo _u('ta790c872c', 'textarea'); ?></h1>
                    <div class="spacer-small"></div>
                    <p class="text-size-large is-hero" data-text="t6c2cea04"><?php echo _u('t6c2cea04','text'); ?></p>
                    <div class="spacer-large"></div>
                    <div class="button-group">
                      <a href="<?php echo _u('a-78721987','link'); ?>" class="button is-alternate w-button" data-text="t55e9256" data-link="a-78721987"><?php echo _u('t55e9256','text'); ?></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="header5_background-image-wrapper">
          <div class="image-overlay-layer"></div><img sizes="100vw" srcset="<?php echo udesly_get_image(_u('i4b2bea34', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i4b2bea34', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i4b2bea34', 'img'))->src ?>" loading="eager" class="header5_background-image" data-img="i4b2bea34">
        </div>
      </header>
      <section id="dlaczego-my" class="section_layout10">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-xlarge">
              <div class="layout10_component">
                <div class="w-layout-grid layout10_content">
                  <div id="w-node-_09c002f0-c659-69d8-42a1-5ed4781d9caa-04305b91" class="layout10_image-wrapper"><img sizes="(max-width: 767px) 90vw, (max-width: 991px) 600px, 42vw" srcset="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->src ?>" loading="lazy" class="layout10_image" data-img="i1d96cb31"></div>
                  <div class="layout10_content-left">
                    <div class="text-style-tagline" data-text="tn31c0e390"><?php echo _u('tn31c0e390','text'); ?></div>
                    <div class="spacer-xsmall"></div>
                    <h2 class="heading-style-h2" data-textarea="ta26da39e7"><?php echo _u('ta26da39e7', 'textarea'); ?></h2>
                    <div class="spacer-small"></div>
                    <p class="text-size-medium" data-text="t9a1d364"><?php echo _u('t9a1d364','text'); ?></p>
                    <div class="spacer-xlarge"></div>
                    <div class="w-layout-grid layout10_item-list">
                      <div class="layout10_item">
                        <div class="layout10_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('in2184dd2d', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('in2184dd2d', 'img'))->alt ?>" class="icon-1x1-small" data-img="in2184dd2d" srcset="<?php echo udesly_get_image(_u('in2184dd2d', 'img'))->srcset ?>"></div>
                        <div class="spacer-xsmall"></div>
                        <h3 class="heading-style-h6" data-text="tn2084476d"><?php echo _u('tn2084476d','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p data-text="te969ea1"><?php echo _u('te969ea1','text'); ?></p>
                      </div>
                      <div class="layout10_item">
                        <div class="layout10_item-icon-wrapper is-yellow"><img loading="lazy" src="<?php echo udesly_get_image(_u('i26c65337', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i26c65337', 'img'))->alt ?>" class="icon-1x1-small" data-img="i26c65337" srcset="<?php echo udesly_get_image(_u('i26c65337', 'img'))->srcset ?>"></div>
                        <div class="spacer-xsmall"></div>
                        <h3 class="heading-style-h6" data-text="tn9b6b6c4"><?php echo _u('tn9b6b6c4','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p data-text="t1ed8ad4d"><?php echo _u('t1ed8ad4d','text'); ?></p>
                      </div>
                    </div>
                    <div class="spacer-medium"></div>
                  </div>
                </div>
              </div>
              <div class="stats8_component">
                <div class="max-width-large"></div>
                <div class="spacer-xlarge"></div>
                <div class="w-layout-grid stats8_list">
                  <div class="stats8_item">
                    <div class="stats8_number" data-text="t145cab"><?php echo _u('t145cab','text'); ?></div>
                    <h3 class="heading-style-h4" data-text="tn5387728e"><?php echo _u('tn5387728e','text'); ?></h3>
                  </div>
                  <div class="stats8_item">
                    <div class="stats8_number" data-text="t625"><?php echo _u('t625','text'); ?></div>
                    <h3 class="heading-style-h4" data-textarea="tan401154cc"><?php echo _u('tan401154cc', 'textarea'); ?></h3>
                  </div>
                  <div class="stats8_item">
                    <div class="stats8_number" data-text="t38"><?php echo _u('t38','text'); ?></div>
                    <h3 class="heading-style-h4" data-text="tn27ae187b"><?php echo _u('tn27ae187b','text'); ?></h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="uslugi" class="section_layout273 text-color-alternate z-index-2">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-xlarge">
              <div class="layout273_component">
                <div class="max-width-large">
                  <h2 data-text="t30c2365f"><?php echo _u('t30c2365f','text'); ?></h2>
                </div>
                <div class="spacer-xxlarge"></div>
                <div class="w-layout-grid layout273_list">
                  <div id="w-node-_8d84bf19-a86c-78bd-7b24-36324e5893c2-04305b91" class="layout273_item">
                    <div class="layout273_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('i773555e7', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i773555e7', 'img'))->alt ?>" class="icon-1x1-medium" data-img="i773555e7" srcset="<?php echo udesly_get_image(_u('i773555e7', 'img'))->srcset ?>"></div>
                    <div class="spacer-large"></div>
                    <h3 data-text="t7461f5e3"><?php echo _u('t7461f5e3','text'); ?></h3>
                    <div class="spacer-small"></div>
                    <p data-text="t35bddd2f"><?php echo _u('t35bddd2f','text'); ?></p>
                  </div>
                  <div id="w-node-_0319b917-0d79-4036-4c4e-cd7efd1dab7d-04305b91" class="layout273_item">
                    <div class="layout273_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('in64d4f23e', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('in64d4f23e', 'img'))->alt ?>" class="icon-1x1-medium" data-img="in64d4f23e" srcset="<?php echo udesly_get_image(_u('in64d4f23e', 'img'))->srcset ?>"></div>
                    <div class="spacer-large"></div>
                    <h3 data-text="t3b3a4489"><?php echo _u('t3b3a4489','text'); ?></h3>
                    <div class="spacer-small"></div>
                    <p data-text="tn4981edb6"><?php echo _u('tn4981edb6','text'); ?></p>
                  </div>
                  <div id="w-node-_47901d3f-90f5-cb6a-56b9-8269c4979364-04305b91" class="layout273_item">
                    <div class="layout273_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('i775184e9', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i775184e9', 'img'))->alt ?>" class="icon-1x1-medium" data-img="i775184e9" srcset="<?php echo udesly_get_image(_u('i775184e9', 'img'))->srcset ?>"></div>
                    <div class="spacer-large"></div>
                    <h3 data-textarea="ta6eb4f72f"><?php echo _u('ta6eb4f72f', 'textarea'); ?></h3>
                    <div class="spacer-small"></div>
                    <p data-text="t3505836a"><?php echo _u('t3505836a','text'); ?></p>
                  </div>
                  <div id="w-node-_1f3bd236-991d-9712-a663-e431f51d8e86-04305b91" class="layout273_item">
                    <div class="layout273_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('i775f9c6a', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i775f9c6a', 'img'))->alt ?>" class="icon-1x1-medium" data-img="i775f9c6a" srcset="<?php echo udesly_get_image(_u('i775f9c6a', 'img'))->srcset ?>"></div>
                    <div class="spacer-large"></div>
                    <h3 data-textarea="tan34a3fd79"><?php echo _u('tan34a3fd79', 'textarea'); ?></h3>
                    <div class="spacer-small"></div>
                    <p data-text="tn651af1d5"><?php echo _u('tn651af1d5','text'); ?></p>
                  </div>
                  <div id="w-node-_0dbceef1-f2fe-a232-8261-beb07abfd873-04305b91" class="layout273_item">
                    <div class="layout273_item-icon-wrapper"><img loading="lazy" src="<?php echo udesly_get_image(_u('i77436d68', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i77436d68', 'img'))->alt ?>" class="icon-1x1-medium" data-img="i77436d68" srcset="<?php echo udesly_get_image(_u('i77436d68', 'img'))->srcset ?>"></div>
                    <div class="spacer-large"></div>
                    <h3 data-textarea="ta44539212"><?php echo _u('ta44539212', 'textarea'); ?></h3>
                    <div class="spacer-small"></div>
                    <p data-text="tn2e61dc7f"><?php echo _u('tn2e61dc7f','text'); ?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="layout273_background-image-wrapper">
          <div class="image-overlay-layer"><img src="<?php echo udesly_get_image(_u('in6d1cd834', 'img'))->src ?>" loading="lazy" alt="<?php echo udesly_get_image(_u('in6d1cd834', 'img'))->alt ?>" data-img="in6d1cd834" srcset="<?php echo udesly_get_image(_u('in6d1cd834', 'img'))->srcset ?>"></div><img sizes="100vw" srcset="<?php echo udesly_get_image(_u('i269ee5fd', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i269ee5fd', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i269ee5fd', 'img'))->src ?>" loading="lazy" class="layout273_background-image" data-img="i269ee5fd">
        </div>
      </section>
      <section class="section_timeline2">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large is-top0 is-timeline">
              <div class="background-color-white z-index-2 section-padding"></div>
              <div class="timeline2_component">
                <div class="w-layout-grid timeline2_content">
                  <div class="timeline2_content-left z-index-2">
                    <div class="text-style-tagline" data-text="tn3a66cd7c"><?php echo _u('tn3a66cd7c','text'); ?></div>
                    <div class="spacer-xsmall"></div>
                    <h2 class="heading-style-h2" data-text="tn1e563369"><?php echo _u('tn1e563369','text'); ?></h2>
                    <div class="spacer-small"></div>
                    <p class="text-size-medium" data-text="t11f6f43c"><?php echo _u('t11f6f43c','text'); ?></p>
                    <div class="spacer-medium is-timeline"></div>
                  </div>
                  <div id="w-node-_7569f423-463f-594f-21b2-2356484223da-04305b91" class="timeline2_progress">
                    <div class="timeline2_fade-overlay-top"></div>
                    <div class="timeline2_progress-line"></div>
                    <div class="timeline2_line"></div>
                    <div class="timeline2_fade-overlay-bottom"></div>
                  </div>
                  <div class="timeline2_content-right">
                    <div class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div data-w-id="7569f423-463f-594f-21b2-2356484223e3" class="timeline2_circle"></div>
                      </div>
                      <div data-w-id="7569f423-463f-594f-21b2-2356484223e4" class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="t1e8bf982"><?php echo _u('t1e8bf982','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="t31855a17"><?php echo _u('t31855a17','text'); ?></p>
                      </div>
                    </div>
                    <div class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div data-w-id="9421fa1e-769b-58dd-fe29-6dd7a0deb5e7" class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="tn40d9ed59"><?php echo _u('tn40d9ed59','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="t47e0f980"><?php echo _u('t47e0f980','text'); ?></p>
                      </div>
                    </div>
                    <div class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div data-w-id="e712b289-2bf6-2cf1-49ad-a5a5ce53572f" class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="t46c95770"><?php echo _u('t46c95770','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="t1cd569a9"><?php echo _u('t1cd569a9','text'); ?></p>
                      </div>
                    </div>
                    <div class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div data-w-id="5f9baa97-3c26-7d12-676f-3d98f72c6323" class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="t22fc55b2"><?php echo _u('t22fc55b2','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="tn230b011d"><?php echo _u('tn230b011d','text'); ?></p>
                      </div>
                    </div>
                    <div class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div data-w-id="bebec6da-5901-1e4e-1adf-cdcacfad444b" class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="tn7ce27256"><?php echo _u('tn7ce27256','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="tn1a6d8bae"><?php echo _u('tn1a6d8bae','text'); ?></p>
                      </div>
                    </div>
                    <div data-w-id="b1e4852f-4abf-ee2b-2863-40cd673ec7a2" class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="tn512f4a0c"><?php echo _u('tn512f4a0c','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="tn5eea074f"><?php echo _u('tn5eea074f','text'); ?></p>
                      </div>
                    </div>
                    <div data-w-id="5ae9dcbd-3942-9f6f-cff2-a7681a4061f4" class="timeline2_row">
                      <div class="timeline2_circle-wrapper">
                        <div class="timeline2_circle"></div>
                      </div>
                      <div class="timeline2_item">
                        <h3 class="heading-style-h4" data-text="t16f5d40b"><?php echo _u('t16f5d40b','text'); ?></h3>
                        <div class="spacer-xsmall"></div>
                        <p class="text-size-medium" data-text="t743f679c"><?php echo _u('t743f679c','text'); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="realizacje" class="section_product11">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large">
              <div class="product11_component">
                <div class="product11_heading-wrapper">
                  <div class="product11_heading">
                    <div class="max-width-large">
                      <h2 class="heading-style-h2" data-text="tn3c8932ae"><?php echo _u('tn3c8932ae','text'); ?></h2>
                    </div>
                  </div>
                </div>
                <div class="spacer-xlarge"></div>
                <div data-delay="4000" data-animation="slide" class="product11_slider w-slider" data-autoplay="false" data-easing="ease" data-hide-arrows="false" data-disable-swipe="false" data-autoplay-limit="0" data-nav-spacing="3" data-duration="500" data-infinite="false">
                  <div class="product11_mask w-slider-mask">
                    <div class="product11_slide w-slide">
                      <div class="product11_item">
                        <div class="product11_image-wrapper"><img sizes="(max-width: 479px) 90vw, (max-width: 767px) 69vw, (max-width: 991px) 64vw, 59vw" srcset="<?php echo udesly_get_image(_u('ine153970', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('ine153970', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('ine153970', 'img'))->src ?>" loading="lazy" class="product11_image" data-img="ine153970"></div>
                        <div class="spacer-xsmall"></div>
                        <div id="w-node-_9cbf0568-f917-7234-1b34-37dc409b87ea-04305b91" class="product11_text-wrapper">
                          <h3 data-text="t3a9fb492"><?php echo _u('t3a9fb492','text'); ?></h3>
                          <div data-text="t2a177f17"><?php echo _u('t2a177f17','text'); ?></div>
                        </div>
                        <div class="spacer-xsmall"></div>
                        <div class="text-power" data-text="t1b32ae1d"><?php echo _u('t1b32ae1d','text'); ?></div>
                      </div>
                    </div>
                    <div class="product11_slide w-slide">
                      <div class="product11_item">
                        <div class="product11_image-wrapper"><img sizes="(max-width: 479px) 90vw, (max-width: 767px) 69vw, (max-width: 991px) 64vw, 59vw" srcset="<?php echo udesly_get_image(_u('i2e5c5076', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i2e5c5076', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i2e5c5076', 'img'))->src ?>" loading="lazy" class="product11_image" data-img="i2e5c5076"></div>
                        <div class="spacer-xsmall"></div>
                        <div id="w-node-d7264448-48f2-3fec-2e4c-09b45952d3b3-04305b91" class="product11_text-wrapper">
                          <h3 data-text="t52c02379"><?php echo _u('t52c02379','text'); ?></h3>
                          <div data-text="t9588e8"><?php echo _u('t9588e8','text'); ?></div>
                        </div>
                        <div class="spacer-xsmall"></div>
                        <div class="text-power" data-text="t2f5634b"><?php echo _u('t2f5634b','text'); ?></div>
                      </div>
                    </div>
                    <div class="product11_slide w-slide">
                      <div class="product11_item">
                        <div class="product11_image-wrapper"><img sizes="(max-width: 479px) 90vw, (max-width: 767px) 69vw, (max-width: 991px) 64vw, 59vw" srcset="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i1d96cb31', 'img'))->src ?>" loading="lazy" class="product11_image" data-img="i1d96cb31"></div>
                        <div class="spacer-xsmall"></div>
                        <div id="w-node-_1ca3ff4f-ba76-0c88-0f1b-470051e8f280-04305b91" class="product11_text-wrapper">
                          <h3 data-text="t52c02379"><?php echo _u('t52c02379','text'); ?></h3>
                          <div data-text="t50c20b0b"><?php echo _u('t50c20b0b','text'); ?></div>
                        </div>
                        <div class="spacer-xsmall"></div>
                        <div class="text-power" data-text="t3ab90265"><?php echo _u('t3ab90265','text'); ?></div>
                      </div>
                    </div>
                    <div class="product11_slide w-slide">
                      <div class="product11_item">
                        <div class="product11_image-wrapper"><img sizes="(max-width: 479px) 90vw, (max-width: 767px) 69vw, (max-width: 991px) 64vw, 59vw" srcset="<?php echo udesly_get_image(_u('i2bef48b9', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('i2bef48b9', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('i2bef48b9', 'img'))->src ?>" loading="lazy" class="product11_image" data-img="i2bef48b9"></div>
                        <div class="spacer-xsmall"></div>
                        <div id="w-node-f3bc7b71-a99a-5003-8b24-fb26077bff09-04305b91" class="product11_text-wrapper">
                          <h3 data-text="t14897ac2"><?php echo _u('t14897ac2','text'); ?></h3>
                          <div data-text="tn1b01dfd6"><?php echo _u('tn1b01dfd6','text'); ?></div>
                        </div>
                        <div class="spacer-xsmall"></div>
                        <div class="text-power" data-text="t3e22b3a3"><?php echo _u('t3e22b3a3','text'); ?></div>
                      </div>
                    </div>
                    <div class="product11_slide w-slide">
                      <div class="product11_item">
                        <div class="product11_image-wrapper"><img sizes="(max-width: 479px) 90vw, (max-width: 767px) 69vw, (max-width: 991px) 64vw, 59vw" srcset="<?php echo udesly_get_image(_u('in2339bf08', 'img'))->srcset ?>" alt="<?php echo udesly_get_image(_u('in2339bf08', 'img'))->alt ?>" src="<?php echo udesly_get_image(_u('in2339bf08', 'img'))->src ?>" loading="lazy" class="product11_image" data-img="in2339bf08"></div>
                        <div class="spacer-xsmall"></div>
                        <div id="w-node-_33b78dce-58e1-4a55-024e-546eb6ebd57f-04305b91" class="product11_text-wrapper">
                          <h3 data-text="t52c02379"><?php echo _u('t52c02379','text'); ?></h3>
                          <div data-text="t4d3e6e6"><?php echo _u('t4d3e6e6','text'); ?></div>
                        </div>
                        <div class="spacer-xsmall"></div>
                        <div class="text-power" data-text="t63c95709"><?php echo _u('t63c95709','text'); ?></div>
                      </div>
                    </div>
                  </div>
                  <div class="slider-arrow is-bottom-previous w-slider-arrow-left"><img src="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->src ?>" loading="lazy" alt="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->alt ?>" class="icon-1x1-xsmall" data-img="in1a2ae9" srcset="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->srcset ?>"></div>
                  <div class="slider-arrow is-bottom-next w-slider-arrow-right"><img src="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->src ?>" loading="lazy" alt="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->alt ?>" class="icon-1x1-xsmall" data-img="in1a2ae9" srcset="<?php echo udesly_get_image(_u('in1a2ae9', 'img'))->srcset ?>"></div>
                  <div class="product11_slide-nav w-slider-nav w-slider-nav-invert w-round"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="kontakt" class="section_contact16">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large is-top0">
              <div class="contact16_component">
                <div class="w-layout-grid contact16_content">
                  <div class="contact16_content-left">
                    <div class="max-width-large">
                      <div class="text-style-tagline" data-text="t43219700"><?php echo _u('t43219700','text'); ?></div>
                      <div class="spacer-xsmall"></div>
                      <h2 class="heading-style-h2" data-text="t1a6392e6"><?php echo _u('t1a6392e6','text'); ?></h2>
                    </div>
                  </div>
                  <div class="contact16_content-right">
                    <div class="w-layout-grid contact16_contact-list">
                      <div id="w-node-_2d481a75-ffa5-41d5-0687-3c152dcbd25a-04305b91" class="contact16_item">
                        <div class="contact16_item-icon-wrapper">
                          <div class="icon-embed-xsmall w-embed"><svg width=" 100%" height=" 100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M20 4H4C2.897 4 2 4.897 2 6V18C2 19.103 2.897 20 4 20H20C21.103 20 22 19.103 22 18V6C22 4.897 21.103 4 20 4ZM20 6V6.511L12 12.734L4 6.512V6H20ZM4 18V9.044L11.386 14.789C11.5611 14.9265 11.7773 15.0013 12 15.0013C12.2227 15.0013 12.4389 14.9265 12.614 14.789L20 9.044L20.002 18H4Z" fill="currentColor"></path>
                            </svg></div>
                        </div>
                        <div class="contact16_item-text-wrapper">
                          <a href="<?php echo _u('a1515b2c6','link'); ?>" class="text-style-link" data-text="tn59e5b432" data-link="a1515b2c6"><?php echo _u('tn59e5b432','text'); ?></a>
                        </div>
                      </div>
                      <div id="w-node-_2d481a75-ffa5-41d5-0687-3c152dcbd263-04305b91" class="contact16_item">
                        <div class="contact16_item-icon-wrapper">
                          <div class="icon-embed-xsmall w-embed"><svg width=" 100%" height=" 100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M17.707 12.293C17.6142 12.2 17.504 12.1263 17.3827 12.076C17.2614 12.0257 17.1313 11.9998 17 11.9998C16.8687 11.9998 16.7386 12.0257 16.6173 12.076C16.496 12.1263 16.3858 12.2 16.293 12.293L14.699 13.887C13.96 13.667 12.581 13.167 11.707 12.293C10.833 11.419 10.333 10.04 10.113 9.30096L11.707 7.70696C11.7999 7.61417 11.8737 7.50397 11.924 7.38265C11.9743 7.26134 12.0002 7.13129 12.0002 6.99996C12.0002 6.86862 11.9743 6.73858 11.924 6.61726C11.8737 6.49595 11.7999 6.38575 11.707 6.29296L7.707 2.29296C7.61421 2.20001 7.50401 2.12627 7.38269 2.07596C7.26138 2.02565 7.13133 1.99976 7 1.99976C6.86866 1.99976 6.73862 2.02565 6.6173 2.07596C6.49599 2.12627 6.38579 2.20001 6.293 2.29296L3.581 5.00496C3.201 5.38496 2.987 5.90696 2.995 6.43996C3.018 7.86396 3.395 12.81 7.293 16.708C11.191 20.606 16.137 20.982 17.562 21.006H17.59C18.118 21.006 18.617 20.798 18.995 20.42L21.707 17.708C21.7999 17.6152 21.8737 17.505 21.924 17.3837C21.9743 17.2623 22.0002 17.1323 22.0002 17.001C22.0002 16.8696 21.9743 16.7396 21.924 16.6183C21.8737 16.4969 21.7999 16.3867 21.707 16.294L17.707 12.293ZM17.58 19.005C16.332 18.984 12.062 18.649 8.707 15.293C5.341 11.927 5.015 7.64196 4.995 6.41896L7 4.41396L9.586 6.99996L8.293 8.29296C8.17546 8.41041 8.08904 8.55529 8.04155 8.71453C7.99406 8.87376 7.987 9.04231 8.021 9.20496C8.045 9.31996 8.632 12.047 10.292 13.707C11.952 15.367 14.679 15.954 14.794 15.978C14.9565 16.0129 15.1253 16.0064 15.2846 15.9591C15.444 15.9117 15.5889 15.825 15.706 15.707L17 14.414L19.586 17L17.58 19.005V19.005Z" fill="currentColor"></path>
                            </svg></div>
                        </div>
                        <div class="contact16_item-text-wrapper">
                          <div data-text="t5033d5e6"><?php echo _u('t5033d5e6','text'); ?></div>
                          <a href="<?php echo _u('a64ddc8c4','link'); ?>" class="text-style-link" data-text="tn994adb9" data-link="a64ddc8c4"><?php echo _u('tn994adb9','text'); ?></a>
                        </div>
                      </div>
                      <div id="w-node-_35f2c00f-ce62-d8b5-825d-f16da1e0ea40-04305b91" class="contact16_item">
                        <div class="contact16_item-icon-wrapper">
                          <div class="icon-embed-xsmall w-embed"><svg width=" 100%" height=" 100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M17.707 12.293C17.6142 12.2 17.504 12.1263 17.3827 12.076C17.2614 12.0257 17.1313 11.9998 17 11.9998C16.8687 11.9998 16.7386 12.0257 16.6173 12.076C16.496 12.1263 16.3858 12.2 16.293 12.293L14.699 13.887C13.96 13.667 12.581 13.167 11.707 12.293C10.833 11.419 10.333 10.04 10.113 9.30096L11.707 7.70696C11.7999 7.61417 11.8737 7.50397 11.924 7.38265C11.9743 7.26134 12.0002 7.13129 12.0002 6.99996C12.0002 6.86862 11.9743 6.73858 11.924 6.61726C11.8737 6.49595 11.7999 6.38575 11.707 6.29296L7.707 2.29296C7.61421 2.20001 7.50401 2.12627 7.38269 2.07596C7.26138 2.02565 7.13133 1.99976 7 1.99976C6.86866 1.99976 6.73862 2.02565 6.6173 2.07596C6.49599 2.12627 6.38579 2.20001 6.293 2.29296L3.581 5.00496C3.201 5.38496 2.987 5.90696 2.995 6.43996C3.018 7.86396 3.395 12.81 7.293 16.708C11.191 20.606 16.137 20.982 17.562 21.006H17.59C18.118 21.006 18.617 20.798 18.995 20.42L21.707 17.708C21.7999 17.6152 21.8737 17.505 21.924 17.3837C21.9743 17.2623 22.0002 17.1323 22.0002 17.001C22.0002 16.8696 21.9743 16.7396 21.924 16.6183C21.8737 16.4969 21.7999 16.3867 21.707 16.294L17.707 12.293ZM17.58 19.005C16.332 18.984 12.062 18.649 8.707 15.293C5.341 11.927 5.015 7.64196 4.995 6.41896L7 4.41396L9.586 6.99996L8.293 8.29296C8.17546 8.41041 8.08904 8.55529 8.04155 8.71453C7.99406 8.87376 7.987 9.04231 8.021 9.20496C8.045 9.31996 8.632 12.047 10.292 13.707C11.952 15.367 14.679 15.954 14.794 15.978C14.9565 16.0129 15.1253 16.0064 15.2846 15.9591C15.444 15.9117 15.5889 15.825 15.706 15.707L17 14.414L19.586 17L17.58 19.005V19.005Z" fill="currentColor"></path>
                            </svg></div>
                        </div>
                        <div class="contact16_item-text-wrapper">
                          <div data-text="t4d3e6e6"><?php echo _u('t4d3e6e6','text'); ?></div>
                          <a href="<?php echo _u('a-2bb5fc88','link'); ?>" class="text-style-link" data-text="tn308b2431" data-link="a-2bb5fc88"><?php echo _u('tn308b2431','text'); ?></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="spacer-medium"></div>
                <div class="contact16_map-wrapper">
                  <div class="w-widget w-widget-map" data-widget-style="roadmap" data-widget-latlng="53.3964659,18.406773" data-enable-scroll="true" role="region" title="" data-enable-touch="true" data-widget-zoom="12" data-widget-tooltip=""></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <footer class="footer4_component">
      <div class="padding-global">
        <div class="container-large">
          <div class="padding-vertical padding-medium is-footer">
            <div class="padding-bottom padding-medium">
              <div class="w-layout-grid footer4_top-wrapper">
                <a href="<?php echo _u('a2f','link'); ?>" id="w-node-_3ddfa075-03aa-216a-2362-2873adcc7a29-04305b91" aria-current="page" class="footer4_logo-link w-nav-brand" data-link="a2f"><img loading="lazy" src="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->src ?>" alt="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->alt ?>" class="footer4_logo" data-img="i7dfc681c" srcset="<?php echo udesly_get_image(_u('i7dfc681c', 'img'))->srcset ?>"></a>
                <div id="w-node-_3ddfa075-03aa-216a-2362-2873adcc7a2b-04305b91" class="w-layout-grid footer4_link-list">
                  <a href="<?php echo _u('a-78721987','link'); ?>" class="footer4_link" data-text="t46975cf" data-link="a-78721987"><?php echo _u('t46975cf','text'); ?></a>
                  <a href="<?php echo _u('a9a885ac','link'); ?>" class="footer4_link" data-text="tn680b60ad" data-link="a9a885ac"><?php echo _u('tn680b60ad','text'); ?></a>
                  <a href="<?php echo _u('aa7d410f','link'); ?>" class="footer4_link" data-text="t260aaccc" data-link="aa7d410f"><?php echo _u('t260aaccc','text'); ?></a>
                  <a href="<?php echo _u('a13b2219d','link'); ?>" class="footer4_link" data-text="t43219700" data-link="a13b2219d"><?php echo _u('t43219700','text'); ?></a>
                </div>
                <div id="w-node-_3ddfa075-03aa-216a-2362-2873adcc7a36-04305b91" class="w-layout-grid footer4_social-list">
                  <a href="<?php echo _u('a2c7f73b7','link'); ?>" target="_blank" class="footer4_social-link w-inline-block" data-link="a2c7f73b7">
                    <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22 12.0611C22 6.50451 17.5229 2 12 2C6.47715 2 2 6.50451 2 12.0611C2 17.0828 5.65684 21.2452 10.4375 22V14.9694H7.89844V12.0611H10.4375V9.84452C10.4375 7.32296 11.9305 5.93012 14.2146 5.93012C15.3088 5.93012 16.4531 6.12663 16.4531 6.12663V8.60261H15.1922C13.95 8.60261 13.5625 9.37822 13.5625 10.1739V12.0611H16.3359L15.8926 14.9694H13.5625V22C18.3432 21.2452 22 17.083 22 12.0611Z" fill="CurrentColor"></path>
                      </svg></div>
                  </a>
                  <a href="<?php echo _u('a-2bb5fc88','link'); ?>" class="footer4_social-link w-inline-block" data-link="a-2bb5fc88">
                    <div class="icon-embed-xsmall w-embed"><svg width=" 100%" height=" 100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.707 12.293C17.6142 12.2 17.504 12.1263 17.3827 12.076C17.2614 12.0257 17.1313 11.9998 17 11.9998C16.8687 11.9998 16.7386 12.0257 16.6173 12.076C16.496 12.1263 16.3858 12.2 16.293 12.293L14.699 13.887C13.96 13.667 12.581 13.167 11.707 12.293C10.833 11.419 10.333 10.04 10.113 9.30096L11.707 7.70696C11.7999 7.61417 11.8737 7.50397 11.924 7.38265C11.9743 7.26134 12.0002 7.13129 12.0002 6.99996C12.0002 6.86862 11.9743 6.73858 11.924 6.61726C11.8737 6.49595 11.7999 6.38575 11.707 6.29296L7.707 2.29296C7.61421 2.20001 7.50401 2.12627 7.38269 2.07596C7.26138 2.02565 7.13133 1.99976 7 1.99976C6.86866 1.99976 6.73862 2.02565 6.6173 2.07596C6.49599 2.12627 6.38579 2.20001 6.293 2.29296L3.581 5.00496C3.201 5.38496 2.987 5.90696 2.995 6.43996C3.018 7.86396 3.395 12.81 7.293 16.708C11.191 20.606 16.137 20.982 17.562 21.006H17.59C18.118 21.006 18.617 20.798 18.995 20.42L21.707 17.708C21.7999 17.6152 21.8737 17.505 21.924 17.3837C21.9743 17.2623 22.0002 17.1323 22.0002 17.001C22.0002 16.8696 21.9743 16.7396 21.924 16.6183C21.8737 16.4969 21.7999 16.3867 21.707 16.294L17.707 12.293ZM17.58 19.005C16.332 18.984 12.062 18.649 8.707 15.293C5.341 11.927 5.015 7.64196 4.995 6.41896L7 4.41396L9.586 6.99996L8.293 8.29296C8.17546 8.41041 8.08904 8.55529 8.04155 8.71453C7.99406 8.87376 7.987 9.04231 8.021 9.20496C8.045 9.31996 8.632 12.047 10.292 13.707C11.952 15.367 14.679 15.954 14.794 15.978C14.9565 16.0129 15.1253 16.0064 15.2846 15.9591C15.444 15.9117 15.5889 15.825 15.706 15.707L17 14.414L19.586 17L17.58 19.005V19.005Z" fill="currentColor"></path>
                      </svg></div>
                  </a>
                  <a href="<?php echo _u('a-27c6917c','link'); ?>" class="footer4_social-link w-inline-block" data-link="a-27c6917c">
                    <div class="icon-embed-xsmall w-embed"><svg width=" 100%" height=" 100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20 4H4C2.897 4 2 4.897 2 6V18C2 19.103 2.897 20 4 20H20C21.103 20 22 19.103 22 18V6C22 4.897 21.103 4 20 4ZM20 6V6.511L12 12.734L4 6.512V6H20ZM4 18V9.044L11.386 14.789C11.5611 14.9265 11.7773 15.0013 12 15.0013C12.2227 15.0013 12.4389 14.9265 12.614 14.789L20 9.044L20.002 18H4Z" fill="currentColor"></path>
                      </svg></div>
                  </a>
                </div>
                <div id="w-node-_9449de64-78e0-7d09-69d1-4268fb4a13f4-04305b91" class="w-layout-grid footer_info">
                  <div data-textarea="tan323eec4d"><?php echo _u('tan323eec4d', 'textarea'); ?></div>
                  <div data-text="tn42b727f3"><?php echo _u('tn42b727f3','text'); ?></div>
                </div>
              </div>
            </div>
            <div class="line-divider"></div>
            <div class="padding-top padding-medium">
              <div class="w-layout-grid footer4_bottom-wrapper">
                <div id="w-node-_3ddfa075-03aa-216a-2362-2873adcc7a44-04305b91" class="footer4_credit-text" data-text="tn2a906474"><?php echo _u('tn2a906474','text'); ?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
  
  