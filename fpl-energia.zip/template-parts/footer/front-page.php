<script type="text/javascript">var $ = window.jQuery;</script><script src="<?php echo get_template_directory_uri(); ?>/assets/js/webflow.js?v=1744192794" type="text/javascript"></script>
<script>
// Number of clicks on the trigger element initially set on 0
let numOfClicks = 0;
// Get trigger element
const trigger = document.getElementById("menu-trigger");
// Get body element
const bodyEl = document.getElementsByTagName("body")[0];
// Set onclick function to trigger element
trigger.onclick = () => {
numOfClicks += 1;
// Check if number of clicks is an even value:
// odd value - first click, even value - second click
const isNumOfClicksEven = numOfClicks % 2 === 0;
// On first click set body's overflow property to "auto",
// On second click set body's overflow property to "hidden"
isNumOfClicksEven ? bodyEl.style.overflow = "auto" : bodyEl.style.overflow = "hidden";
};
</script><script type="module">import*as UdeslyBanner from"https://cdn.jsdelivr.net/npm/udesly-ad-banner@0.0.4/loader/index.js";UdeslyBanner.defineCustomElements(),document.body.append(document.createElement("udesly-banner"));</script>